-- AlterTable
ALTER TABLE `note` MODIFY `text` TEXT NOT NULL;
