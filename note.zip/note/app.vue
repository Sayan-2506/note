<template>
  <div>
    <NuxtPage />
  </div>
</template>

<style>
.font-playfair {
  font-family: "Playfair", serif;
  font-optical-sizing: auto;
  font-weight: 400;
  font-style: normal;
  font-variation-settings:
    "wdth" 100;
}

* {
  font-family: "Inter", sans-serif;
}
</style>